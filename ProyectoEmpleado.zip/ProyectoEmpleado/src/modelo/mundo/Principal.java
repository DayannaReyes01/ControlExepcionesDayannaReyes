package modelo.mundo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner lect = new Scanner (System.in);
		
		
		Empleado empleado1 = null;
		
		//declarar variables para pedir al usuario los datos del empleado que van a ingresar 
		 String nombreEmplea ;
		 String apellidoEmple;
		 int genero; // 1 Femenido & 2 Masculino
		 String imagen;
		 double salario;
		 int dia, mes, anio;
		 int opc = 0;
		 
		 Fecha fechaNac;
		 Fecha fechaIngreso;
	
		 do { 
		System.out.println("Escoja una de las opciones del siguiente menu");
		System.out.println("	1. Ingreso de datos del empleado.");
		System.out.println("	2. Calcular la edad del empleado");
		System.out.println("	3. Calcular la antig�edad del empleado en la empresa");
		System.out.println("	4. Calcular las prestaciones del empleado.");
		System.out.println("	5. Visualizar la informaci�n del empleado");
		System.out.println("	6. Salir del programa");
		
		do {
		try {
			System.out.println("Escoja una opci�n = "); opc= lect.nextInt();
		}
		catch(InputMismatchException e){
			System.out.println("Ingrese solo los numeros que se encuentran en el menu");
			opc = 6;
			e.printStackTrace();
		}
		}while(opc<1|| opc>6);
		
		switch (opc) {
		case 1: 
		Scanner entrada = new Scanner(System.in);
		 System.out.println("\nIngreso de datos del empleado");
		 System.out.println("\nNombre: ");
		 nombreEmplea = entrada.nextLine();
		 
		 System.out.println("\nApellido: ");
		 apellidoEmple = entrada.nextLine();
		 
		 //GENERO
		 do {
	        	try {
					System.out.println("Genero (1 para masculino, 2 para femenino): ");
					//Colocar while
					genero= entrada.nextInt();
								
				}
				catch(InputMismatchException e) {
					System.out.println("Debe ingresar solo n�meros ");
					genero = 0;
					//genero= scanner.nextInt();
					//e.printStackTrace();
					entrada.nextLine();
				}
	        }while (genero<1 || genero>2);
		 
		//SALARIO
		 do {
				try {
					System.out.println("Ingrese su salario: ");
					salario=entrada.nextDouble();
			     if(salario<=0) {
				System.out.println(" El salario debe ser un numero mayor a 0");	
			}
				}
				catch(InputMismatchException e) {
					System.out.println("Debe ingresar solo numeros");
					salario=0;
					entrada.nextLine();
				}
			}while(salario<=0);
		 
		 //DIA DE NACIMIENTO
		 do {
	        	try {
					System.out.println("\nIngrese dia de nacimiento : ");
					//Colocar while
					dia= entrada.nextInt();
								
				}
				catch(InputMismatchException me) {
					System.out.println("Debe ingresar solo n�meros de 1 a 31 ");
					dia = 0;
					entrada.nextLine();
				}
	        }while (dia<1 || dia>31);
		 
		 
		 //MES DE NACIMIENTO
		 do {
	        	try {
					System.out.println("\nIngese mes de nacimiento : ");
					mes= entrada.nextInt();			
				}
				catch(InputMismatchException me) {
					System.out.println("Debe ingresar solo n�meros de 1 a 12 ");
					mes = 0;
					entrada.nextLine();
				}
	        }while (mes<1 || mes>12);
		 
		 //A�O DE NACIMIENTO
		 do {
			 	try {
		 
				 System.out.println("\nIngrese anio de nacimiento");
				 anio = entrada.nextInt();	 
				 }
			 	
			 	catch(InputMismatchException e) {
				 System.out.println("Sole debe ingresar valores enteros, mayores a 0");
				 anio = 0;
				 entrada.nextLine();
			 	}
		 	}while (anio<1 || anio>2021);
		 
		 
		 fechaNac = new Fecha( dia, mes, anio);
		 
		        //DIA DE INGRESO
		 do {
	        	try {
					System.out.println("\nIngrese dia de ingreso : ");
					//Colocar while
					dia= entrada.nextInt();
					
								
				}
				catch(InputMismatchException m) {
					System.out.println("Debe ingresar solo n�meros de 1 a 31 ");
					dia = 0;
					entrada.nextLine();
				}
	        }while (dia<1 || dia>31);
		 
		 		//MES DE INGRESO
		 do {
	        	try {
					System.out.println("\nIngese mes de ingreso : ");
					mes= entrada.nextInt();			
				}
				catch(InputMismatchException a) {
					System.out.println("Debe ingresar solo n�meros de 1 a 12 ");
					mes = 0;
					entrada.nextLine();
				}
	        }while (mes<1 || mes>12);
		 
		 		//A�O DE INGRESO
		 do {
			 	try {
		 
				 System.out.println("\nIngrese anio de ingreso");
				 anio = entrada.nextInt();	 
				 }
			 	
			 	catch(InputMismatchException e) {
				 System.out.println("Sole debe ingresar valores enteros, mayores a 0");
				 anio = 0;
				 entrada.nextLine();
			 	}
		 	}while (anio<1 || anio>2021);
		 
		 
		 fechaIngreso = new Fecha(dia, mes, anio);
		
		 empleado1 = new Empleado (nombreEmplea, apellidoEmple, genero, "", salario,  fechaNac, fechaIngreso);
		 
		 break;
		 
		case 2:
			System.out.println("\nHa seleccionado la opci�n 2");
			System.out.println("Calcular la edad del empleado");
			System.out.println("Su edad es: " + empleado1.calcularEdad());
			
			break;
			
		case 3:
			System.out.println("\nHa seleccionado la opci�n 3");
			System.out.println("Calcular la antiguedad del empleado en la empresa");
			System.out.println("Su antiguedad en la empresa es: "+ empleado1.calcularAntiguedad());
			break;
		
		case 4:
			System.out.println("\nHa seleccionado la opci�n 4");
			System.out.println("Calcular las prestaciones del empleado");
			System.out.println("Sus prestaciones son: " + empleado1.calcularAntiguedad());
			
			break;
		
		case 5:
			System.out.println("\nHa seleccionado la opci�n 5");
			System.out.println("Visualizar la informaci�n del empleado");
			empleado1.mostrarInformaic�n();
			
			break;
			
		default:
			System.out.println("No ha seleccionado ninguna opcion del menu");
			}
		}while (opc != 6);
	}

}
