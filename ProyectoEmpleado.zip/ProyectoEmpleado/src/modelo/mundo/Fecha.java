package modelo.mundo;

public class Fecha {
	private int dia;
	private int mes;
	private int anio;
	
	
	//Constructores
	public Fecha  (int pDia, int pMes, int pAnio ) {
		dia = pDia;
		mes = pMes;
		anio = pAnio;
	}
	
	
	//Constructor sin parametros
	
	public Fecha  () {
		dia = 0;
		mes = 0;
		anio = 0;
	}
	
	//Metodo analizadores getters
	public int getDia() {
		return dia;
	}
	
	public int getMes() {
		return mes;
	}
	
	public int getAnio() {
		return anio;
	}
	
	
	//Metodo Funcionales. devuelve un valor entero 
	// fecha1 23/04/2000  fecha2 12/08/2008
	public int darDifereneciaEnMeses (Fecha pFecha) {
		//Completar codigo
		int numeroMeses = 0;
		
		int difanios = pFecha.getAnio() - anio * 12;
		
		int difMese = 0;
		if ( mes < pFecha.getMes()) {
			difMese = pFecha.getMes() - mes;
		}
		
		int difDias = 0;
		if (mes < pFecha.getMes()) {
			difDias = (pFecha.getDia() - dia )/ 30;
		}
		
		numeroMeses = difanios + difMese + difDias;
		
		return numeroMeses;
	}
	
	//ddmmaaaa  //dd/mm/aaaa //aaa-mm-dd
	public String toString() {
		return dia + "-" + mes + "-" + anio;
	}

}
